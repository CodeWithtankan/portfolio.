from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def form_example():
    if request.method == 'POST':
        input_name = request.form['input_text']
       input_email = request.form['input_text']
        return f'{input_text} was submitted!'
    return render_template('index.html')